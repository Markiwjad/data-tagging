import torch
import torch as t
import torch.nn as nn
from torch.nn import functional as F
from torch.utils.data import DataLoader
from dataloader import VV_AHU_Dataset,VV_AHU_Dataset_Single,load_data,dump_data
import torch.optim as optim
import os
from sklearn.metrics import roc_curve, auc
from sklearn.metrics import f1_score,precision_score,recall_score,roc_auc_score,accuracy_score,roc_curve
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import GradientBoostingClassifier

hidden_dim = 256
embedding_dim = 288


class bigru_attention(nn.Module):
    def __init__(self,hidden_dim):
        super(bigru_attention, self).__init__()
        self.hidden_dim = hidden_dim
        self.gru_layers = 2

        # 双向GRU，//操作为了与后面的Attention操作维度匹配，hidden_dim要取偶数！
        self.bigru = nn.GRU(embedding_dim, hidden_dim // 2,
                            num_layers=self.gru_layers, bidirectional=True)
        # 由nn.Parameter定义的变量都为requires_grad=True状态
        self.weight_W = nn.Parameter(torch.Tensor(hidden_dim, hidden_dim))
        self.weight_proj = nn.Parameter(torch.Tensor(hidden_dim, 1))
        # 二分类
        self.fc = nn.Linear(hidden_dim, 2)

        nn.init.uniform_(self.weight_W, -0.1, 0.1)
        nn.init.uniform_(self.weight_proj, -0.1, 0.1)

    def forward(self, in_left,in_right):
        # print(in_left.shape)
        # print(in_right.shape)
        in_left = in_left.permute(1,0,2)
        in_right = in_right.permute(1,0,2)

        gru_out_l, _ = self.bigru(in_left)  # [seq_len, bs, hid_dim]
        # print('gru_out_1',gru_out_l)
        gru_out_r, _ = self.bigru(in_right)  # [seq_len, bs, hid_dim]
        # print('gru_out_r', gru_out_r)
        gru_out = torch.cat((gru_out_l,gru_out_r),dim=0)
        x = gru_out.permute(1, 0, 2)
        # print('x',x)
        # # # Attention过程，与上图中三个公式对应
        u = torch.tanh(torch.matmul(x, self.weight_W))
        att = torch.matmul(u, self.weight_proj)
        # print('att',att)
        att_score = F.softmax(att, dim=1)
        # print('att_score', att_score)
        scored_x = x * att_score
        # # # Attention过程结束
        # print('score',scored_x.shape)

        feat = torch.sum(scored_x, dim=1)
        # print('feat',feat,shape)
        y = self.fc(feat)
        return y
def train(train_data):
    # hyper parameters
    EPOCH = 60
    BATCH_SIZE = 256
    use_cuda = True
    # ------输入VAV AHU全部特征-----
    # LR = 0.0001
    # weight_decay = 0.00001
    # ------输入VAV AHU 单一个特征---
    LR = 0.0001
    weight_decay = 0.00001
    num_workers = 0

    train_dataloader = t.utils.data.DataLoader(train_data, batch_size=BATCH_SIZE,shuffle=True,num_workers=num_workers,)
    bigru_att = bigru_attention(hidden_dim=64)
    if use_cuda:
        bigru_att.to('cuda')
    optimizer = optim.Adam(params=bigru_att.parameters(), lr=LR, weight_decay=weight_decay)
    criterion = t.nn.CrossEntropyLoss()
    running_loss = 0.0
    for epoch in range(EPOCH):
        print(epoch,'--'*100)
        for ii, (data, label) in enumerate(train_dataloader):
            inputs = data
            # print('inpputs',inputs)
            # if use_cuda:
            inputs[0] = inputs[0].float().to('cuda')
            inputs[1] = inputs[1].float().to('cuda')
            # print('input[0]',inputs[0].shape)
            # print('input[1]',inputs[1].shape)
            labels = label.long().to('cuda')

            target = bigru_att(inputs[0],inputs[1])
            # print('target', target)
            # print('label', labels)
            loss = criterion(target, labels)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            running_loss += loss.item()

            if (ii + 1) % 100 == 0:
                # print(ii, running_loss / 1000)
                print('Epoch:', epoch, 'ii:',ii+1,'|train loss: %.4f' % (running_loss/100))
                running_loss = 0.0
    # ------输入VAV AHU全部特征------
    # 保存模型参数
    # t.save(bigru_att.state_dict(), 'E:\wss/bigru_att.pth')
    # ------输入VAV AHU 单一个特征------
    t.save(bigru_att.state_dict(), 'E:\wss/bigru_att_single_0.pth')

def test(test_data):
    test_dataloader = t.utils.data.DataLoader(test_data, batch_size=256, shuffle=True, num_workers=0)

    gru_model = bigru_attention(hidden_dim=64)
    # 输入全部VAV AHU特征
    # gru_model.load_state_dict(t.load('E:\wss/bigru_att.pth'))
    # 输入 VAV AHU 单一个特征
    gru_model.load_state_dict(t.load('E:\wss/bigru_att_single.pth'))
    gru_model.to('cuda')
    gru_model.eval()
    correct = 0
    total = len(test_dataloader.dataset)
    count_predict = [0, 0]
    count_total = [0, 0]
    count_right = [0, 0]
    confusion_matrix = torch.zeros(2,2)
    FPR = []
    TPR = []
    ROC_AUC = []
    THRESHOLD = []
    for (data, label) in test_dataloader:
        inputs = data
        inputs[0] = inputs[0].float().to('cuda')
        inputs[1] = inputs[1].float().to('cuda')
        labels = label.long().to('cuda')
        # print('labels',labels)
        target = gru_model(inputs[0], inputs[1])
        pre = target.argmax(dim=1)
        # 计算混淆矩阵
        for l, p in zip(labels, pre):
            confusion_matrix[l.long(), p.long()] += 1

        for y1, y2 in zip(pre, labels):
            count_predict[y1] += 1
            count_total[y2] += 1
            if y1 == y2:
                correct += 1
                count_right[y1] += 1
        # ROC曲线
        pre_ROC = pre.data.cpu().numpy()
        labels_ROC = labels.data.cpu().numpy()
        fpr,tpr,threshold = roc_curve(pre_ROC,labels_ROC)
        FPR.extend(fpr)
        TPR.extend(tpr)
        THRESHOLD.extend(threshold)
        roc_auc = auc(fpr,tpr)
        ROC_AUC.append(roc_auc)
    print(count_predict)
    print(count_total)
    print(count_right)
    print(confusion_matrix)
    print(FPR)
    print(len(FPR))
    print(TPR)
    print(len(TPR))
    print(THRESHOLD)
    print(len(THRESHOLD))
    print(ROC_AUC)
    print(len(ROC_AUC))
    # print(confusion_matrix.diag() / confusion_matrix.sum(1))
    # print(confusion_matrix.diag() / confusion_matrix.sum(0))
    accuracy = 100 * float(correct) / total
    precision = [0, 0]
    recall = [0, 0]
    for i in range(len(count_predict)):
        if count_predict[i] != 0:
            precision[i] = float(count_right[i]) / count_predict[i]
        if count_total[i] != 0:
            recall[i] = float(count_right[i]) / count_total[i]
    precision = sum(precision) / 2
    recall = sum(recall) / 2
    f1 = (2 * precision * recall) / (precision + recall)
    print('accuracy:{}%'.format(accuracy),
          '|precision:{}'.format(precision),
          'recall:{}'.format(recall), 'f1:{}'.format(f1))
    print('start ROC')
    # plt.figure()
    # lw = 2
    # plt.figure(figsize=(10, 10))
    # plt.plot(FPR, TPR, color='darkorange',
    #          lw=lw, label='ROC curve (area = %0.2f)' % ROC_AUC)  ###假正率为横坐标，真正率为纵坐标做曲线
    # plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
    # plt.xlim([0.0, 1.0])
    # plt.ylim([0.0, 1.05])
    # plt.xlabel('False Positive Rate')
    # plt.ylabel('True Positive Rate')
    # plt.title('Receiver operating characteristic example')
    # plt.legend(loc="lower right")
    # plt.show()

if __name__ == '__main__':
    # 划分训练集和测试集
    # ---------------训练前只运行一次-------------
    # print('start splitting dataset')
    # ------输入VAV AHU全部特征------
    # total_data = VV_AHU_Dataset()
    # ------输入VAV AHU 单一个特征-----
    # total_data = VV_AHU_Dataset_Single()
    # train_size = int(len(total_data) * 0.9)
    # test_size = len(total_data) - train_size
    # train_data, test_data = torch.utils.data.random_split(total_data, [train_size, test_size])
    # ------输入VAV AHU全部特征------
    # dump_data(train_data,'E:\wss/train_data.pkl')
    # dump_data(test_data,'E:\wss/test_data.pkl')
    # -----输入VAV AHU 单一个特征-----
    # dump_data(train_data, 'E:\wss/train_data_single.pkl')
    # dump_data(test_data,'E:\wss/test_data_single.pkl')
    # print('split over')

    # ------输入VAV AHU全部特征------
    # train_data = load_data('E:\wss/train_data.pkl')
    # -----输入VAV AHU 单一个特征-----
    # train_data = load_data('E:\wss/train_data_single.pkl')
    # train(train_data)
    # ------输入VAV AHU全部特征------
    # test_data = load_data('E:\wss/test_data.pkl')
    # -----输入VAV AHU 单一个特征-----
    test_data = load_data('E:\wss/test_data_single.pkl')
    test(test_data)