#%matplotlib inline
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import load_wine
import random
import sklearn.preprocessing as preprocessing

import pickle
from xlwt import *


# import xlwt
file = Workbook(encoding='utf-8')
table = file.add_sheet('result')
table.write(0, 0, '序号')
table.write(0, 1, 'max_features')
table.write(0, 2, 'max_depth')
table.write(0, 3, 'n_estamitors')
table.write(0, 4, 'min_samples_leaf')
table.write(0, 5, 'score')



data = pickle.load(open('vv_airflow_data.data','rb'))
label = pickle.load(open('vv_flow_label.label','rb'))
# data_new=[]
# for i in data:
#     i=list(i)
#     data_new.append(i)



data_new=np.mat(data)
np.random.shuffle(data_new)
random.shuffle(label)

scaler = preprocessing.StandardScaler()
#x=scaler.fit_transform(new_data)
x=scaler.fit_transform(data_new)

from sklearn.model_selection import train_test_split
Xtrain, Xtest, Ytrain, Ytest = train_test_split(data_new,label,test_size=0.3)
#clf = DecisionTreeClassifier(random_state=0)

#parameterization
num_hang=1
count=1
list_features=['auto','log2']#'auto','sqrt',
list_depth=[2,5,10,None]
# for i in list_features:#max_features
for j in range(10,101,30):#n_estamitors 10 40 70 100
    for k in range(500,601,10):#min_samples_leaf 50 100 150 200 250 300 350 400 450 500
        for l in list_depth:#max_depth
            for i in list_features:  # max_features
                rfc = RandomForestClassifier(n_estimators=j,min_samples_leaf=k,max_features=i,max_depth=l,random_state=0)
                rfc = rfc.fit(Xtrain,Ytrain)
                score_r = rfc.score(Xtest,Ytest)
                table.write(num_hang, 0, count)#
                table.write(num_hang,1,i)# max_features
                table.write(num_hang, 2, l)#max_depth
                table.write(num_hang, 3, j)#n_estamitors
                table.write(num_hang, 4, k)#min_samples_leaf
                table.write(num_hang, 5, score_r)
                count+=1
                num_hang+=1

print("count=",count)
print("num_hang=",num_hang)
file.save('result.xls')






